# SHUBAAD Full Platform

AI-driven environmental resilience intelligence platform.

## What is included
- Frontend HTML dashboard
- Python FastAPI backend
- Dataset upload
- CSV/XLSX reading
- Column validation
- PCA
- PLS EC prediction
- R2, RMSE, RPD
- Resilience score
- PCA and prediction plots
- AI interpretation report

## Run backend locally
```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

Backend runs at:
```text
http://127.0.0.1:8000
```

## Run frontend
Open:
```text
frontend/index.html
```

## Required dataset columns
Minimum:
- Sample_ID
- EC
- At least two numeric predictors

Recommended:
- pH, OM, SOC, Sand, Silt, Clay
- FTIR_3400, FTIR_2920, FTIR_1630, FTIR_1540, FTIR_1030
- OSI, PSI, NDVI

## Deployment
- Frontend: Vercel
- Backend: Render, Railway, Google Cloud, or AWS

After deploying backend, change API_BASE inside frontend/index.html.
