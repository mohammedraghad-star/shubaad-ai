from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import numpy as np
from io import BytesIO
import base64
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.cross_decomposition import PLSRegression
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_squared_error

app = FastAPI(title="SHUBAAD AI Backend", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

REQUIRED = ["Sample_ID", "EC"]
RECOMMENDED = [
    "pH", "OM", "SOC", "Sand", "Silt", "Clay",
    "FTIR_3400", "FTIR_2920", "FTIR_1630", "FTIR_1540", "FTIR_1030",
    "OSI", "PSI", "NDVI"
]

def read_table(file: UploadFile, content: bytes) -> pd.DataFrame:
    name = file.filename.lower()
    if name.endswith(".csv") or name.endswith(".txt"):
        return pd.read_csv(BytesIO(content))
    if name.endswith(".xlsx"):
        return pd.read_excel(BytesIO(content))
    raise HTTPException(status_code=400, detail="Only CSV, TXT, and XLSX are supported.")

def fig_to_b64():
    buf = BytesIO()
    plt.tight_layout()
    plt.savefig(buf, format="png", dpi=180, bbox_inches="tight")
    plt.close()
    buf.seek(0)
    return base64.b64encode(buf.read()).decode("utf-8")

def make_pca_plot(scores, ec, var1, var2):
    plt.figure(figsize=(7,5))
    sc = plt.scatter(scores[:,0], scores[:,1], c=ec, s=55)
    plt.xlabel(f"PC1 ({var1:.1f}%)")
    plt.ylabel(f"PC2 ({var2:.1f}%)")
    plt.title("SHUBAAD PCA Score Plot")
    plt.colorbar(sc, label="EC")
    plt.grid(alpha=0.25)
    return fig_to_b64()

def make_prediction_plot(y, pred, r2, rmse):
    plt.figure(figsize=(7,5))
    plt.scatter(y, pred, s=55)
    mn, mx = float(min(y.min(), pred.min())), float(max(y.max(), pred.max()))
    plt.plot([mn, mx], [mn, mx], linestyle="--")
    plt.xlabel("Observed EC")
    plt.ylabel("Predicted EC")
    plt.title(f"PLS EC Prediction | R²={r2:.2f}, RMSE={rmse:.3f}")
    plt.grid(alpha=0.25)
    return fig_to_b64()

@app.get("/")
def root():
    return {"status": "SHUBAAD backend is running"}

@app.post("/analyze")
async def analyze(file: UploadFile = File(...)):
    content = await file.read()
    df = read_table(file, content)
    df.columns = [str(c).strip() for c in df.columns]

    missing_required = [c for c in REQUIRED if c not in df.columns]
    if missing_required:
        raise HTTPException(status_code=400, detail=f"Missing required columns: {missing_required}")

    numeric_cols = []
    for c in df.columns:
        if c != "Sample_ID":
            df[c] = pd.to_numeric(df[c], errors="coerce")
            if df[c].notna().sum() >= 5:
                numeric_cols.append(c)

    feature_cols = [
        c for c in numeric_cols
        if c != "EC" and (
            c.startswith("FTIR_") or c in ["pH","OM","SOC","Sand","Silt","Clay","OSI","PSI","NDVI","LST","NDWI","Salinity_Index"]
        )
    ]

    if len(feature_cols) < 2:
        raise HTTPException(status_code=400, detail="Need at least two numeric predictor columns, preferably FTIR peaks/indices/GIS variables.")

    model_df = df[["EC"] + feature_cols].dropna()
    if len(model_df) < 6:
        raise HTTPException(status_code=400, detail="Need at least 6 complete numeric samples for PCA/PLS analysis.")

    X = model_df[feature_cols].values
    y = model_df["EC"].values

    Xs = StandardScaler().fit_transform(X)

    pca = PCA(n_components=2)
    scores = pca.fit_transform(Xs)
    pc1, pc2 = pca.explained_variance_ratio_[0]*100, pca.explained_variance_ratio_[1]*100

    ncomp = min(3, X.shape[1], len(model_df)-2)
    pls = PLSRegression(n_components=max(1, ncomp))
    if len(model_df) >= 10:
        cv = KFold(n_splits=min(5, len(model_df)), shuffle=True, random_state=42)
        pred = cross_val_predict(pls, Xs, y, cv=cv).ravel()
        validation_type = "cross-validated"
    else:
        pls.fit(Xs, y)
        pred = pls.predict(Xs).ravel()
        validation_type = "calibration-only"

    r2 = float(r2_score(y, pred))
    rmse = float(np.sqrt(mean_squared_error(y, pred)))
    rpd = float(np.std(y, ddof=1) / rmse) if rmse > 0 else 999.0

    pca_img = make_pca_plot(scores, y, pc1, pc2)
    pred_img = make_prediction_plot(y, pred, r2, rmse)

    avg_ec = float(np.nanmean(y))
    avg_ndvi = float(np.nanmean(model_df["NDVI"])) if "NDVI" in model_df.columns else 0.4
    resilience_score = int(max(0, min(100, round(70 - avg_ec*4 + avg_ndvi*50))))

    missing_recommended = [c for c in RECOMMENDED if c not in df.columns]
    validation_message = "Dataset validated and analyzed successfully."
    if missing_recommended:
        validation_message += " Missing recommended columns: " + ", ".join(missing_recommended)

    report = f"""
    <p><b>Dataset analyzed:</b> {len(model_df)} complete samples and {len(feature_cols)} predictors were used.</p>
    <p class="mt-3"><b>PCA:</b> PC1 explained {pc1:.1f}% and PC2 explained {pc2:.1f}% of standardized predictor variance.</p>
    <p class="mt-3"><b>PLS EC prediction:</b> The {validation_type} model achieved R² = <b>{r2:.2f}</b>, RMSE = <b>{rmse:.3f}</b>, and RPD = <b>{rpd:.2f}</b>.</p>
    <p class="mt-3"><b>Resilience score:</b> {resilience_score}/100 based on average EC and NDVI availability.</p>
    <p class="mt-3"><b>Scientific caution:</b> This is a first operational SHUBAAD engine. For Q1 publication, add external validation, VIP scores, permutation testing, and transparent preprocessing documentation.</p>
    """

    return {
        "filename": file.filename,
        "samples": int(len(model_df)),
        "variables": int(len(feature_cols)),
        "columns": list(df.columns),
        "feature_columns": feature_cols,
        "validation_message": validation_message,
        "pca": {"pc1_variance": pc1, "pc2_variance": pc2},
        "model": {"type": "PLSRegression", "validation": validation_type, "r2": r2, "rmse": rmse, "rpd": rpd},
        "resilience_score": resilience_score,
        "plots": {"pca": pca_img, "prediction": pred_img},
        "report": report
    }
